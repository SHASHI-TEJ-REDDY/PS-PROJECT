function support() {
    window.open("support.html");
}
function deployy() {
    window.open("depoly.html", "_self");
}
function report() {
    window.open("report_a_bug.html");
}
function Labeler() {
    window.open("labeler.html");
}
function admin() {
    window.open("admin.html", "_self");
}
function register() {
    window.open("user.html");
}
function verify() {
    window.open("verify.html");
}
function requestpatch() {
    window.open("request_patch.html");
}